# Pmanager 
This is a project management system built with Laravel 5.5

## Tutorial
The video tutorials for this repo is on youtube, please do well to subscribe: https://www.youtube.com/watch?v=oltgtexDbdo&list=PLnBvgoOXZNCP2LEKmvu2W-eUkO-DYn0TL

## Usage
1. Install laravel
2. Run Migrations
3. Signup a user and log in
Enjoy

The follow the youtube channel for the tutorial on the steps above. 

That's all, you are good to go.


I can join your team, you can contact me.

## How to thank me
* Star this repo
Follow me on my social media handles
* Subscribe on [Youtube](http://youtube.com/c/braintemorg)
* Follow on [Twitter](http://twitter.com/braintem)
* Follow on [Instagram](http://instagram.com/daveozoalor)
* Like on [Facebook](http://fb.com/braintem)


## Contacts

* You can reach the me on `daveozoalor@gmail.com`, I'd like to join your team.
* Just buzz me up on [facebook](http://facebook.com/daveozoalor)

## License

This software is open-sourced software licensed under the [MIT license](http://opensource.org/licenses/MIT).
